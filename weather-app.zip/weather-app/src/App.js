import React from 'react';
import './App.css';
import Nav from './components/navbar/Navbar';
import OneDay from './components/Oneday';


function App() {
 console.log("shit")
  return (
    <div className="App">
      <h3>WEATHER APP</h3>
      <Nav />
      <OneDay />
   
    </div>
  );

}
export default App;