import React from 'react';


function Titles(){
return (
<div>
<h1> Weather Forecast</h1>
<p>find current weather conditions. </p>

</div>

)


}


export default Titles; 