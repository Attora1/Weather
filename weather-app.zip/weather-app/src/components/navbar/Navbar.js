import React from 'react';
import {BrowserRouter, Route,} from 'react-router-dom';
import Week from '../Fiveday'
import Day from '../Oneday'

function Nav(){
    return (
        // <Router>
        //     <div>
        //         <nav>
        //             <ul>
        //                 <li>
        //                     <Link exact path="/">Today's Weather</Link>
        //                 </li>
        //                 <li>
        //                     <Link to="../pages/Fiveday.js">5 Day Forecast</Link>
        //                 </li>
        //             </ul>
        //         </nav>
        
        //         <Switch>
        //             <Route path="/" ></Route>
        //             <Route path="../pages/Fiveday.js" component={Week}></Route>
        //         </Switch>
        //     </div>
        //  </Router>
            <BrowserRouter>
              <div>
                  <Route path="/Fiveday.js" component={Week} />
                  <Route path="/" component={Day} />
              </div>
            </BrowserRouter>
        
    )


}

export default Nav; 